/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package itse_prog;

import java.util.Scanner;
import javax.swing.JOptionPane;

public class Itse_Prog {
      public static String  username;                                         
       public static String password;
       public static String firstName;
      public static  String lastName;
      public static boolean loggedIn = false;
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null, "Welcome to EasyKanban");
        registration();

       
        int totalHours = 0;
        String menuChoice = "";

        while (!menuChoice.equals("3")) {
            if (loggedIn) {
                menuChoice = JOptionPane.showInputDialog("Menu:\n- Input '1' to Add tasks\n- Input '2' to Show report\n- Input '3' to Quit");
                switch (menuChoice) {
                case "1":
                    if (loggedIn) {
                        int numTasks = Integer.parseInt(JOptionPane.showInputDialog("Enter the number of tasks: "));

                        for (int i = 0; i < numTasks; i++) {
                            String taskName = JOptionPane.showInputDialog("Enter task name: ");
                            String taskDescription = JOptionPane.showInputDialog("Enter task description: ");
                            String developerFirstName = JOptionPane.showInputDialog("Enter developer first name: ");                            
                            String developerLastName = JOptionPane.showInputDialog("Enter developer last name: ");

                            int taskDuration = Integer.parseInt(JOptionPane.showInputDialog("Enter task duration in hours: "));
                            String taskStatus = JOptionPane.showInputDialog("Enter task status (To Do, Done, Doing): ");

                            Task task = new Task(taskName, taskDescription, developerFirstName,developerLastName , taskDuration, taskStatus,i);
                            totalHours += task.getTaskDuration();

                            JOptionPane.showMessageDialog(null, task.printTaskDetails());
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "Please login to add tasks.");
                    }
                    break;

                case "2":
                    JOptionPane.showMessageDialog(null, "Coming Soon");
                    break;

                case "3":
                    JOptionPane.showMessageDialog(null, "Total combined hours of all tasks: " + totalHours);
                    break;
                    
                default:
                    JOptionPane.showMessageDialog(null, "Invalid choice. Please try again.");
                    break;
            }
                
            } else {
                menuChoice = JOptionPane.showInputDialog("Menu: \n- Input '1' to Login\n- Input '2' to Quit");
                
                switch (menuChoice) {
                
                case "1":
                    Login login = new Login(username, password, firstName, lastName);
                    String loginStatus = login.returnLoginStatus(username, password);
                    JOptionPane.showMessageDialog(null, loginStatus);
                    loggedIn = login.loginUser(username, password);
                    break;
                    
                    case "2":
                    JOptionPane.showMessageDialog(null, "Total combined hours of all tasks: " + totalHours);
                    break;

                default:
                    JOptionPane.showMessageDialog(null, "Invalid choice. Please try again.");
                    break;
            }
            }

            
        }
    }
    public static void  registration(){
         username = JOptionPane.showInputDialog("REGISTRATION \n"
                                                      + "Enter your username: ");
         
         password = JOptionPane.showInputDialog("Enter your password: ");
         
         firstName = JOptionPane.showInputDialog("Enter your first name: ");
         lastName = JOptionPane.showInputDialog("Enter your last name: ");
         
         Login register = new Login(username, password, firstName, lastName);
                    String registrationStatus = register.registerUser();
                    JOptionPane.showMessageDialog(null, registrationStatus);
        if (registrationStatus != "User registered successfully!") {
            registration();
        }
    }
    
}
   
  
       
       
       
       
       
       
       
       
       
        

    
    

